<?php

declare(strict_types=1);

require __DIR__ . '/db.php';
require __DIR__ . '/session.php';

start_app_session();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

const PACKAGE_NAME = 'FIDE_PROYECTOFINALACADEMIALEIVA_PCK';
const ESTADO_ACTIVO = 1;
const ESTADO_INACTIVO = 2;

$catalogs = [
    'estados' => catalog('FIDE_ESTADOS_V', 'Estados', 'FIDE_ESTADOS_TB', [num_field('id', 'ID_ESTADO', 'ID Estado')], [text_field('nombre', 'NOMBRE_ESTADO', 'Nombre del estado')], false, ['id', 'nombre'], ['id', 'nombre'], ['id', '__inactive_name']),
    'tipotarjetas' => simple_catalog('FIDE_TIPOTARJETAS_V', 'Tipo de Tarjetas', 'FIDE_TIPOTARJETAS_TB', 'id', 'ID_TIPOTARJETA', 'ID Tipo Tarjeta', 'nombre', 'COLOR', 'Color'),
    'cantones' => simple_catalog('FIDE_CANTONES_V', 'Cantones', 'FIDE_CANTONES_TB', 'id', 'ID_CANTON', 'ID Canton', 'nombre', 'NOMBRE_CANTON', 'Nombre de canton'),
    'cargos' => simple_catalog('FIDE_CARGOS_V', 'Cargos', 'FIDE_CARGOS_TB', 'id', 'ID_CARGO', 'ID Cargo', 'nombre', 'NOMBRE_CARGO', 'Nombre de cargo'),
    'categorias' => simple_catalog('FIDE_CATEGORIAS_V', 'Categorias Deportivas', 'FIDE_CATEGORIAS_TB', 'id', 'ID_CATEGORIA', 'ID Categoria', 'nombre', 'NOMBRE_CATEGORIA', 'Nombre de categoria'),
    'categoria_inventario' => simple_catalog('FIDE_CATEGORIA_INVENTARIO_V', 'Categorias de Inventario', 'FIDE_CATEGORIA_INVENTARIO_TB', 'id', 'ID_CATEGORIAINVENTARIO', 'ID Categoria Inventario', 'nombre', 'NOMBRE_CATEGORIA_INVENTARIO', 'Nombre de categoria inventario'),
    'distritos' => simple_catalog('FIDE_DISTRITOS_V', 'Distritos', 'FIDE_DISTRITOS_TB', 'id', 'ID_DISTRITO', 'ID Distrito', 'nombre', 'NOMBRE_DISTRITO', 'Nombre de distrito'),
    'especialidades' => simple_catalog('FIDE_ESPECIALIDADES_V', 'Especialidades', 'FIDE_ESPECIALIDADES_TB', 'id', 'ID_ESPECIALIDAD', 'ID Especialidad', 'nombre', 'NOMBRE_ESPECIALIDAD', 'Nombre de especialidad'),
    'posiciones' => simple_catalog('FIDE_POSICIONES_V', 'Posiciones', 'FIDE_POSICIONES_TB', 'id', 'ID_POSICION', 'ID Posicion', 'nombre', 'NOMBRE_POSICION', 'Nombre de posicion'),
    'provincias' => simple_catalog('FIDE_PROVINCIAS_V', 'Provincias', 'FIDE_PROVINCIAS_TB', 'id', 'ID_PROVINCIA', 'ID Provincia', 'nombre', 'NOMBRE_PROVINCIA', 'Nombre de provincia'),
    'tipolesion' => simple_catalog('FIDE_TIPOLESION_V', 'Tipo Lesion', 'FIDE_TIPOLESION_TB', 'id', 'ID_TIPOLESION', 'ID Tipo Lesion', 'nombre', 'NOMBRE_TIPO_LESION', 'Nombre tipo lesion', true, true),
    'tipo_partidos' => simple_catalog('FIDE_TIPO_PARTIDOS_V', 'Tipo Partidos', 'FIDE_TIPO_PARTIDOS_TB', 'id', 'ID_TIPOPARTIDOS', 'ID Tipo Partido', 'nombre', 'TIPO_DE_PARTIDO', 'Tipo de partido', true, true),
    'temporadas' => catalog('FIDE_TEMPORADAS_V', 'Temporadas', 'FIDE_TEMPORADAS_TB', [num_field('id', 'ID_TEMPORADA', 'ID Temporada')], [text_field('tipo_temporada', 'TIPO_TEMPORADA', 'Tipo temporada'), num_field('anio', 'ANIO', 'Anio')], true, ['id', 'tipo_temporada', 'anio', 'id_estado'], ['id', 'tipo_temporada', 'anio', 'id_estado'], ['id']),
    'articulos' => catalog('FIDE_ARTICULOS_V', 'Articulos', 'FIDE_ARTICULOS_TB', [num_field('id', 'ID_ARTICULO', 'ID Articulo')], [num_field('id_categoriainventario', 'ID_CATEGORIAINVENTARIO', 'ID Categoria inventario'), num_field('cantidad', 'CANTIDAD', 'Cantidad'), text_field('nombre_articulo', 'NOMBRE_ARTICULO', 'Nombre articulo')], true, ['id', 'id_categoriainventario', 'id_estado', 'cantidad', 'nombre_articulo'], ['id', 'id_categoriainventario', 'id_estado', 'cantidad', 'nombre_articulo'], ['id']),
    'direccion_exacta' => catalog('FIDE_DIRECCION_EXACTA_V', 'Direccion Exacta', 'FIDE_DIRECCION_EXACTA_TB', [num_field('id', 'ID_DIRECCION_EXACTA', 'ID Direccion')], [text_field('otras_senias', 'OTRAS_SENIAS', 'Otras senias'), num_field('id_distrito', 'ID_DISTRITO', 'ID Distrito'), num_field('id_canton', 'ID_CANTON', 'ID Canton'), num_field('id_provincia', 'ID_PROVINCIA', 'ID Provincia')], true, ['id', 'otras_senias', 'id_distrito', 'id_canton', 'id_provincia', 'id_estado'], ['id', 'otras_senias', 'id_distrito', 'id_canton', 'id_provincia', 'id_estado'], ['id']),
    'medicos' => catalog('FIDE_MEDICOS_V', 'Medicos', 'FIDE_MEDICOS_TB', [num_field('id', 'ID_MEDICO', 'ID Medico')], [text_field('nombre', 'NOMBRE', 'Nombre'), text_field('apellido_paterno', 'APELLIDO_PATERNO', 'Apellido paterno'), text_field('apellido_materno', 'APELLIDO_MATERNO', 'Apellido materno'), num_field('id_especialidad', 'ID_ESPECIALIDAD', 'ID Especialidad')], true, ['id', 'nombre', 'apellido_paterno', 'apellido_materno', 'id_especialidad', 'id_estado'], ['id', 'nombre', 'apellido_paterno', 'apellido_materno', 'id_especialidad', 'id_estado'], ['id']),
    'empleados' => catalog('FIDE_EMPLEADOS_V', 'Empleados', 'FIDE_EMPLEADOS_TB', [num_field('id', 'ID_EMPLEADO', 'ID Empleado')], [text_field('nombre', 'NOMBRE', 'Nombre'), text_field('apellido_paterno', 'APELLIDO_PATERNO', 'Apellido paterno'), text_field('apellido_materno', 'APELLIDO_MATERNO', 'Apellido materno'), num_field('edad', 'EDAD', 'Edad'), text_field('nombre_de_usuario', 'NOMBRE_DE_USUARIO', 'Usuario'), text_field('contrasenia', 'CONTRASENIA', 'Contrasenia'), num_field('id_cargo', 'ID_CARGO', 'ID Cargo'), num_field('id_direccion_exacta', 'ID_DIRECCION_EXACTA', 'ID Direccion')], true, ['id', 'nombre', 'apellido_paterno', 'apellido_materno', 'edad', 'nombre_de_usuario', 'contrasenia', 'id_cargo', 'id_direccion_exacta', 'id_estado'], ['id', 'nombre', 'apellido_paterno', 'apellido_materno', 'edad', 'nombre_de_usuario', 'contrasenia', 'id_cargo', 'id_direccion_exacta', 'id_estado'], ['id']),
    'jugadores' => catalog('FIDE_JUGADORES_V', 'Jugadores', 'FIDE_JUGADORES_TB', [num_field('id', 'ID_JUGADOR', 'ID Jugador')], [num_field('id_categoria', 'ID_CATEGORIA', 'ID Categoria'), text_field('nombre', 'NOMBRE', 'Nombre'), text_field('apellido_materno', 'APELLIDO_MATERNO', 'Apellido materno'), text_field('apellido_paterno', 'APELLIDO_PATERNO', 'Apellido paterno'), num_field('dorsal', 'DORSAL', 'Dorsal'), num_field('edad', 'EDAD', 'Edad'), num_field('id_direccion_exacta', 'ID_DIRECCION_EXACTA', 'ID Direccion')], true, ['id', 'id_categoria', 'nombre', 'apellido_materno', 'apellido_paterno', 'dorsal', 'edad', 'id_estado', 'id_direccion_exacta'], ['id', 'id_categoria', 'nombre', 'apellido_materno', 'apellido_paterno', 'dorsal', 'edad', 'id_estado', 'id_direccion_exacta'], ['id']),
    'sedes' => catalog('FIDE_SEDES_V', 'Sedes', 'FIDE_SEDES_TB', [num_field('id', 'ID_SEDE', 'ID Sede')], [text_field('nombre_sede', 'NOMBRE_SEDE', 'Nombre sede'), num_field('id_direccion_exacta', 'ID_DIRECCION_EXACTA', 'ID Direccion')], true, ['id', 'nombre_sede', 'id_direccion_exacta', 'id_estado'], ['id', 'nombre_sede', 'id_direccion_exacta', 'id_estado'], ['id']),
    'jugador_posiciones' => catalog('FIDE_JUGADOR_POSICIONES_V', 'Jugador Posiciones', 'FIDE_JUGADOR_POSICIONES_TB', [num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador'), num_field('id_posicion_actual', 'ID_POSICION', 'ID Posicion')], [num_field('id_posicion_nueva', 'ID_POSICION', 'ID Posicion nueva')], false, ['id_jugador', 'id_posicion_actual'], ['id_jugador', 'id_posicion_actual', 'id_posicion_nueva'], ['id_jugador', 'id_posicion_actual']),
    'parte_medico' => catalog('FIDE_PARTE_MEDICO_V', 'Parte Medico', 'FIDE_PARTE_MEDICO_TB', [num_field('id', 'ID_PARTEMEDICO', 'ID Parte medico')], [num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador'), text_field('observaciones', 'OBSERVACIONES', 'Observaciones'), date_field('fecha', 'FECHA', 'Fecha'), num_field('id_medico', 'ID_MEDICO', 'ID Medico')], true, ['id', 'id_jugador', 'observaciones', 'fecha', 'id_medico', 'id_estado'], ['id', 'id_jugador', 'observaciones', 'fecha', 'id_medico', 'id_estado'], ['id']),
    'partidos' => catalog('FIDE_PARTIDOS_V', 'Partidos', 'FIDE_PARTIDOS_TB', [num_field('id', 'ID_PARTIDO', 'ID Partido')], [num_field('id_categoria', 'ID_CATEGORIA', 'ID Categoria'), num_field('id_tipopartidos', 'ID_TIPOPARTIDOS', 'ID Tipo partido'), num_field('id_temporada', 'ID_TEMPORADA', 'ID Temporada'), date_field('fecha', 'FECHA', 'Fecha'), text_field('rival', 'RIVAL', 'Rival'), num_field('goles_favor', 'GOLES_FAVOR', 'Goles favor'), num_field('goles_contra', 'GOLES_CONTRA', 'Goles contra'), num_field('id_sede', 'ID_SEDE', 'ID Sede')], true, ['id', 'id_categoria', 'id_tipopartidos', 'id_temporada', 'fecha', 'rival', 'goles_favor', 'goles_contra', 'id_sede', 'id_estado'], ['id', 'id_categoria', 'id_tipopartidos', 'id_temporada', 'fecha', 'rival', 'goles_favor', 'goles_contra', 'id_sede', 'id_estado'], ['id']),
    'revision_fisica' => catalog('FIDE_REVISION_FISICA_V', 'Revision Fisica', 'FIDE_REVISION_FISICA_TB', [num_field('id', 'ID_REVISION', 'ID Revision')], [num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador'), num_field('peso', 'PESO', 'Peso'), num_field('imc', 'IMC', 'IMC'), num_field('altura', 'ALTURA', 'Altura'), date_field('fecha_revision', 'FECHA_REVISION', 'Fecha revision')], true, ['id', 'id_jugador', 'peso', 'imc', 'altura', 'fecha_revision', 'id_estado'], ['id', 'id_jugador', 'peso', 'imc', 'altura', 'fecha_revision', 'id_estado'], ['id']),
    'telefonos' => catalog('FIDE_TELEFONOS_V', 'Telefonos', 'FIDE_TELEFONOS_TB', [num_field('id', 'ID_TELEFONO', 'ID Telefono')], [text_field('numero_telefono', 'NUMERO_TELEFONO', 'Numero telefono'), num_field('id_empleado', 'ID_EMPLEADO', 'ID Empleado')], true, ['id', 'numero_telefono', 'id_empleado', 'id_estado'], ['id', 'numero_telefono', 'id_empleado', 'id_estado'], ['id']),
    'asistencia' => catalog('FIDE_ASISTENCIA_V', 'Asistencia', 'FIDE_ASISTENCIA_TB', [num_field('id_partido', 'ID_PARTIDO', 'ID Partido'), num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador')], [], true, ['id_partido', 'id_jugador', 'id_estado'], ['id_partido', 'id_jugador', 'id_estado'], ['id_partido', 'id_jugador']),
    'estadistica_equipo' => catalog('FIDE_ESTADISTICA_EQUIPO_V', 'Estadistica Equipo', 'FIDE_ESTADISTICA_EQUIPO_TB', [num_field('id', 'ID_ESTADISTICA_EQUIPO', 'ID Estadistica equipo')], [num_field('tiros', 'TIROS', 'Tiros'), num_field('tiros_porteria', 'TIROS_PORTERIA', 'Tiros porteria'), num_field('pases_exitosos', 'PASES_EXITOSOS', 'Pases exitosos'), num_field('pases_fallidos', 'PASES_FALLIDOS', 'Pases fallidos'), num_field('posesion_balon', 'POSESION_BALON', 'Posesion balon'), num_field('id_partido', 'ID_PARTIDO', 'ID Partido')], true, ['id', 'tiros', 'tiros_porteria', 'pases_exitosos', 'pases_fallidos', 'posesion_balon', 'id_partido', 'id_estado'], ['id', 'tiros', 'tiros_porteria', 'pases_exitosos', 'pases_fallidos', 'posesion_balon', 'id_partido', 'id_estado'], ['id']),
    'estadistica_jugador' => catalog('FIDE_ESTADISTICA_JUGADOR_V', 'Estadistica Jugador', 'FIDE_ESTADISTICA_JUGADOR_TB', [num_field('id', 'ID_ESTADISTICA_JUGADOR', 'ID Estadistica jugador')], [num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador'), num_field('id_partido', 'ID_PARTIDO', 'ID Partido'), num_field('pases', 'PASES', 'Pases'), num_field('pases_exitosos', 'PASES_EXITOSOS', 'Pases exitosos'), num_field('regates', 'REGATES', 'Regates'), num_field('regates_exitosos', 'REGATES_EXITOSOS', 'Regates exitosos'), num_field('tiros', 'TIROS', 'Tiros'), num_field('tiros_exitosos', 'TIROS_EXITOSOS', 'Tiros exitosos'), num_field('entradas', 'ENTRADAS', 'Entradas'), num_field('entradas_exitosas', 'ENTRADAS_EXITOSAS', 'Entradas exitosas'), num_field('minutos_jugados', 'MINUTOS_JUGADOS', 'Minutos jugados'), num_field('goles', 'GOLES', 'Goles'), num_field('asistencias', 'ASISTENCIAS', 'Asistencias')], true, ['id', 'id_jugador', 'id_partido', 'pases', 'pases_exitosos', 'regates', 'regates_exitosos', 'tiros', 'tiros_exitosos', 'entradas', 'entradas_exitosas', 'minutos_jugados', 'goles', 'asistencias', 'id_estado'], ['id', 'id_jugador', 'id_partido', 'pases', 'pases_exitosos', 'regates', 'regates_exitosos', 'tiros', 'tiros_exitosos', 'entradas', 'entradas_exitosas', 'minutos_jugados', 'goles', 'asistencias', 'id_estado'], ['id']),
    'lesiones' => catalog('FIDE_LESIONES_V', 'Lesiones', 'FIDE_LESIONES_TB', [num_field('id', 'ID_LESION', 'ID Lesion')], [text_field('descripcion', 'DESCRIPCION', 'Descripcion'), date_field('fecha_recuperacion', 'FECHA_RECUPERACION', 'Fecha recuperacion'), num_field('id_tipolesion', 'ID_TIPOLESION', 'ID Tipo lesion'), num_field('id_partemedico', 'ID_PARTEMEDICO', 'ID Parte medico')], true, ['id', 'descripcion', 'fecha_recuperacion', 'id_tipolesion', 'id_partemedico', 'id_estado'], ['id', 'descripcion', 'fecha_recuperacion', 'id_tipolesion', 'id_partemedico', 'id_estado'], ['id']),
    'tarjetas' => catalog('FIDE_TARJETAS_V', 'Tarjetas', 'FIDE_TARJETAS_TB', [num_field('id_partido', 'ID_PARTIDO', 'ID Partido'), num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador'), num_field('id_tipotarjeta', 'ID_TIPOTARJETA', 'ID Tipo tarjeta')], [num_field('cantidad_tarjetas', 'CANTIDAD_TARJETAS', 'Cantidad tarjetas')], true, ['id_partido', 'id_jugador', 'id_tipotarjeta', 'cantidad_tarjetas', 'id_estado'], ['id_partido', 'id_jugador', 'id_tipotarjeta', 'cantidad_tarjetas', 'id_estado'], ['id_partido', 'id_jugador', 'id_tipotarjeta']),
    'facturacion_inscripciones' => catalog('FIDE_FACTURACION_INSCRIPCIONES_V', 'Facturacion Inscripciones', 'FIDE_FACTURACION_INSCRIPCIONES_TB', [num_field('id', 'ID_FACTURACION_INSCRIPCION', 'ID Factura')], [num_field('id_jugador', 'ID_JUGADOR', 'ID Jugador'), num_field('mes', 'MES', 'Mes'), num_field('anio', 'ANIO', 'Anio'), num_field('monto', 'MONTO', 'Monto'), date_field('fecha_pago', 'FECHA_PAGO', 'Fecha pago'), text_field('observaciones', 'OBSERVACIONES', 'Observaciones')], true, ['id', 'id_jugador', 'mes', 'anio', 'monto', 'fecha_pago', 'id_estado', 'observaciones'], ['id', 'id_jugador', 'mes', 'anio', 'monto', 'fecha_pago', 'id_estado', 'observaciones'], ['id']),
];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    if (!isset($_SESSION['empleado'])) {
        send_json(['error' => 'Debe iniciar sesion para usar el panel administrativo.'], 401);
    }

    $catalogKey = $_GET['catalogo'] ?? 'estados';
    if (!isset($catalogs[$catalogKey])) {
        send_json(['error' => 'Catalogo no permitido.'], 400);
    }

    $config = $catalogs[$catalogKey];

    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            list_catalog($config);
            break;
        case 'POST':
            save_catalog($config, false);
            break;
        case 'PUT':
            save_catalog($config, true);
            break;
        case 'DELETE':
            delete_catalog($config);
            break;
        default:
            send_json(['error' => 'Metodo no permitido.'], 405);
    }
} catch (Throwable $exception) {
    send_json(['error' => $exception->getMessage()], 500);
}

function catalog(string $view, string $label, string $tableBase, array $pkFields, array $fields, bool $hasEstado, array $insertParams, array $updateParams, array $deleteParams): array
{
    return [
        'view' => $view,
        'label' => $label,
        'pk_fields' => $pkFields,
        'fields' => $fields,
        'has_estado' => $hasEstado,
        'insert' => $tableBase . '_INSERTAR_SP',
        'update' => $tableBase . '_MODIFICAR_SP',
        'delete' => $tableBase . '_ELIMINAR_SP',
        'insert_params' => $insertParams,
        'update_params' => $updateParams,
        'delete_params' => $deleteParams,
    ];
}

function simple_catalog(string $view, string $label, string $tableBase, string $idKey, string $idColumn, string $idLabel, string $nameKey, string $nameColumn, string $nameLabel, bool $hasEstado = true, bool $deleteOnlyId = false): array
{
    $deleteParams = $hasEstado && !$deleteOnlyId ? [$idKey, 'id_estado'] : [$idKey];
    return catalog($view, $label, $tableBase, [num_field($idKey, $idColumn, $idLabel)], [text_field($nameKey, $nameColumn, $nameLabel)], $hasEstado, [$idKey, $nameKey, 'id_estado'], [$idKey, $nameKey, 'id_estado'], $deleteParams);
}

function num_field(string $key, string $column, string $label): array
{
    return field($key, $column, $label, 'number');
}

function text_field(string $key, string $column, string $label): array
{
    return field($key, $column, $label, 'text');
}

function date_field(string $key, string $column, string $label): array
{
    return field($key, $column, $label, 'date');
}

function field(string $key, string $column, string $label, string $type): array
{
    return ['key' => $key, 'column' => $column, 'label' => $label, 'type' => $type];
}

function list_catalog(array $config): void
{
    $connection = db_connection();
    $orderColumn = $config['pk_fields'][0]['column'];
    $sql = "SELECT T.*" . ($config['has_estado'] ? ", E.NOMBRE_ESTADO" : "") . "
            FROM {$config['view']} T";

    if ($config['has_estado']) {
        $sql .= " LEFT JOIN FIDE_ESTADOS_V E ON E.ID_ESTADO = T.ID_ESTADO";
    }

    $sql .= " ORDER BY T.{$orderColumn}";

    $statement = oci_parse($connection, $sql);
    execute_or_fail($statement, 'No fue posible listar los registros.');

    $records = [];
    while (($row = oci_fetch_assoc($statement)) !== false) {
        $records[] = $row;
    }

    oci_free_statement($statement);

    send_json([
        'message' => 'Registros cargados correctamente.',
        'catalog' => $config['label'],
        'records' => $records,
    ]);
}

function save_catalog(array $config, bool $isUpdate): void
{
    $data = read_json_body();
    $params = $isUpdate ? $config['update_params'] : $config['insert_params'];
    $values = collect_values($config, $data, true, $params);
    $procedure = $isUpdate ? $config['update'] : $config['insert'];

    call_procedure($config, $procedure, $params, $values, 'No fue posible ejecutar el procedimiento.');

    send_json([
        'message' => $isUpdate ? 'Registro actualizado correctamente.' : 'Registro insertado correctamente.',
    ], $isUpdate ? 200 : 201);
}

function delete_catalog(array $config): void
{
    $data = read_json_body();
    if (!$data) {
        $data = $_GET;
    }

    $values = collect_values($config, $data, false, $config['delete_params']);
    foreach ($config['delete_params'] as $param) {
        if ($param === '__inactive_name') {
            $values[$param] = 'Inactivo';
        } elseif ($param === 'id_estado') {
            $values[$param] = ESTADO_INACTIVO;
        }
    }

    call_procedure($config, $config['delete'], $config['delete_params'], $values, 'No fue posible eliminar logicamente el registro.');
    send_json(['message' => 'Registro desactivado correctamente.']);
}

function collect_values(array $config, array $data, bool $requireAll = true, ?array $requiredKeys = null): array
{
    $values = [];
    $fieldMap = get_field_map($config);
    $requiredKeys = $requiredKeys ?? array_keys($fieldMap);

    foreach ($fieldMap as $key => $field) {
        $value = $data[$key] ?? null;

        if ($key === 'id_estado' && ($value === null || $value === '')) {
            $value = ESTADO_ACTIVO;
        }

        if ($requireAll && in_array($key, $requiredKeys, true) && $key !== 'id_estado' && ($value === null || $value === '')) {
            send_json(['error' => "Debe enviar {$field['label']}."], 400);
        }

        $values[$key] = normalize_value($value, $field);
    }

    return $values;
}

function get_field_map(array $config): array
{
    $fields = [];
    foreach (array_merge($config['pk_fields'], $config['fields']) as $field) {
        $fields[$field['key']] = $field;
    }

    if ($config['has_estado']) {
        $fields['id_estado'] = num_field('id_estado', 'ID_ESTADO', 'Estado');
    }

    return $fields;
}

function normalize_value($value, array $field)
{
    if ($value === null || $value === '') {
        return null;
    }

    if ($field['type'] === 'number') {
        return is_numeric($value) && strpos((string) $value, '.') !== false ? (float) $value : (int) $value;
    }

    return trim((string) $value);
}

function call_procedure(array $config, string $procedure, array $params, array $values, string $message): void
{
    $connection = db_connection();
    $fieldMap = get_field_map($config);
    $fullProcedure = PACKAGE_NAME . '.' . $procedure;
    $placeholders = [];
    $binds = [];

    foreach ($params as $index => $key) {
        $placeholder = ":p{$index}";
        $field = $fieldMap[$key] ?? ['type' => 'text'];
        $placeholders[] = ($field['type'] ?? '') === 'date'
            ? "TO_DATE({$placeholder}, 'YYYY-MM-DD')"
            : $placeholder;
        $binds[$placeholder] = $values[$key] ?? null;
    }

    $sql = "BEGIN {$fullProcedure}(" . implode(', ', $placeholders) . "); END;";
    $statement = oci_parse($connection, $sql);
    if (!$statement) {
        $error = oci_error($connection);
        throw new RuntimeException($error['message'] ?? 'No fue posible preparar el procedimiento.');
    }

    foreach ($binds as $placeholder => $value) {
        oci_bind_by_name($statement, $placeholder, $binds[$placeholder], 255);
    }

    execute_or_fail($statement, $message);
    oci_commit($connection);
    oci_free_statement($statement);
}

function execute_or_fail($statement, string $message): void
{
    $success = oci_execute($statement, OCI_NO_AUTO_COMMIT);
    if (!$success) {
        $error = oci_error($statement);
        throw new RuntimeException($error['message'] ?? $message);
    }
}

function read_json_body(): array
{
    $rawBody = file_get_contents('php://input');
    $data = json_decode($rawBody ?: '{}', true);

    if (!is_array($data)) {
        send_json(['error' => 'JSON invalido.'], 400);
    }

    return $data;
}

function send_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
