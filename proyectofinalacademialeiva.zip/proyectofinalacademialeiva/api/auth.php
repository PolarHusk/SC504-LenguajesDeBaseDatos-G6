<?php

declare(strict_types=1);

require __DIR__ . '/db.php';
require __DIR__ . '/session.php';

start_app_session();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    $action = $_GET['action'] ?? 'status';

    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'status') {
        send_json([
            'authenticated' => isset($_SESSION['empleado']),
            'user' => $_SESSION['empleado'] ?? null,
        ]);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        send_json(['error' => 'Metodo no permitido.'], 405);
    }

    if ($action === 'login') {
        login();
    }

    if ($action === 'logout') {
        $_SESSION = [];
        session_destroy();
        send_json(['message' => 'Sesion cerrada correctamente.']);
    }

    send_json(['error' => 'Accion no permitida.'], 400);
} catch (Throwable $exception) {
    send_json(['error' => $exception->getMessage()], 500);
}

function login(): void
{
    $data = read_json_body();
    $usuario = trim((string) ($data['usuario'] ?? ''));
    $contrasenia = trim((string) ($data['contrasenia'] ?? ''));

    if ($usuario === '' || $contrasenia === '') {
        send_json(['error' => 'Debe digitar usuario y contrasenia.'], 400);
    }

    $connection = db_connection();
    $sql = "SELECT ID_EMPLEADO, NOMBRE, APELLIDO_PATERNO, APELLIDO_MATERNO, NOMBRE_DE_USUARIO
            FROM FIDE_EMPLEADOS_V
            WHERE NOMBRE_DE_USUARIO = :usuario
              AND CONTRASENIA = :contrasenia
              AND ID_ESTADO = 1";

    $statement = oci_parse($connection, $sql);
    oci_bind_by_name($statement, ':usuario', $usuario, 100);
    oci_bind_by_name($statement, ':contrasenia', $contrasenia, 100);

    if (!oci_execute($statement)) {
        $error = oci_error($statement);
        throw new RuntimeException($error['message'] ?? 'No fue posible validar el usuario.');
    }

    $empleado = oci_fetch_assoc($statement);
    oci_free_statement($statement);

    if (!$empleado) {
        send_json(['error' => 'Usuario o contrasenia incorrectos.'], 401);
    }

    $_SESSION['empleado'] = [
        'id' => $empleado['ID_EMPLEADO'],
        'usuario' => $empleado['NOMBRE_DE_USUARIO'],
        'nombre' => trim(($empleado['NOMBRE'] ?? '') . ' ' . ($empleado['APELLIDO_PATERNO'] ?? '') . ' ' . ($empleado['APELLIDO_MATERNO'] ?? '')),
    ];

    send_json([
        'message' => 'Ingreso correcto.',
        'user' => $_SESSION['empleado'],
    ]);
}

function read_json_body(): array
{
    $rawBody = file_get_contents('php://input');
    $data = json_decode($rawBody ?: '{}', true);

    if (!is_array($data)) {
        send_json(['error' => 'JSON invalido.'], 400);
    }

    return $data;
}

function send_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
