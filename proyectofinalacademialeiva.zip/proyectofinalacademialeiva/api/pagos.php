<?php

declare(strict_types=1);

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

const ESTADO_ACTIVO = 1;

try {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        buscar_jugador();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        pagar_inscripcion();
    }

    send_json(['error' => 'Metodo no permitido.'], 405);
} catch (Throwable $exception) {
    send_json(['error' => $exception->getMessage()], 500);
}

function buscar_jugador(): void
{
    $cedula = filter_input(INPUT_GET, 'cedula', FILTER_VALIDATE_INT);
    if (!$cedula || $cedula <= 0) {
        send_json(['error' => 'Debe digitar un numero de cedula valido.'], 400);
    }

    $connection = db_connection();
    $sql = "SELECT ID_JUGADOR,
                   NOMBRE,
                   APELLIDO_PATERNO,
                   APELLIDO_MATERNO,
                   DORSAL,
                   EDAD,
                   NOMBRE_CATEGORIA,
                   NOMBRE_ESTADO
            FROM FIDE_DETALLE_JUGADORES_V
            WHERE ID_JUGADOR = :cedula";

    $statement = oci_parse($connection, $sql);
    oci_bind_by_name($statement, ':cedula', $cedula);
    execute_or_fail($statement, 'No fue posible buscar el jugador.');
    $jugador = oci_fetch_assoc($statement);
    oci_free_statement($statement);

    if (!$jugador) {
        send_json(['error' => 'No se encontro un jugador con esa cedula.'], 404);
    }

    $pagos = pagos_jugador($connection, (int) $jugador['ID_JUGADOR']);

    send_json([
        'message' => 'Jugador encontrado.',
        'jugador' => $jugador,
        'pagos' => $pagos,
    ]);
}

function pagar_inscripcion(): void
{
    $data = read_json_body();
    $idJugador = nullable_int($data['id_jugador'] ?? null);
    $mes = nullable_int($data['mes'] ?? null);
    $anio = nullable_int($data['anio'] ?? null);
    $monto = nullable_float($data['monto'] ?? null);
    $observaciones = trim((string) ($data['observaciones'] ?? ''));

    if (!$idJugador || !$mes || !$anio || $monto === null) {
        send_json(['error' => 'Debe completar jugador, mes, anio y monto.'], 400);
    }

    if ($mes < 1 || $mes > 12 || $anio < 2000 || $monto < 0) {
        send_json(['error' => 'Los datos del pago no cumplen las reglas del esquema.'], 400);
    }

    $connection = db_connection();

    if (!jugador_existe($connection, $idJugador)) {
        send_json(['error' => 'El jugador seleccionado no existe.'], 404);
    }

    $existente = pago_existente($connection, $idJugador, $mes, $anio);
    $idEstado = ESTADO_ACTIVO;

    if ($existente) {
        $sql = "UPDATE FIDE_FACTURACION_INSCRIPCIONES_TB
                SET MONTO = :monto,
                    FECHA_PAGO = SYSDATE,
                    ID_ESTADO = :id_estado,
                    OBSERVACIONES = :observaciones
                WHERE ID_FACTURACION_INSCRIPCION = :id_factura";
        $statement = oci_parse($connection, $sql);
        oci_bind_by_name($statement, ':monto', $monto);
        oci_bind_by_name($statement, ':id_estado', $idEstado);
        oci_bind_by_name($statement, ':observaciones', $observaciones, 255);
        oci_bind_by_name($statement, ':id_factura', $existente);
    } else {
        $idFactura = siguiente_id_factura($connection);
        $sql = "INSERT INTO FIDE_FACTURACION_INSCRIPCIONES_TB
                    (ID_FACTURACION_INSCRIPCION, ID_JUGADOR, MES, ANIO, MONTO, FECHA_PAGO, ID_ESTADO, OBSERVACIONES)
                VALUES
                    (:id_factura, :id_jugador, :mes, :anio, :monto, SYSDATE, :id_estado, :observaciones)";
        $statement = oci_parse($connection, $sql);
        oci_bind_by_name($statement, ':id_factura', $idFactura);
        oci_bind_by_name($statement, ':id_jugador', $idJugador);
        oci_bind_by_name($statement, ':mes', $mes);
        oci_bind_by_name($statement, ':anio', $anio);
        oci_bind_by_name($statement, ':monto', $monto);
        oci_bind_by_name($statement, ':id_estado', $idEstado);
        oci_bind_by_name($statement, ':observaciones', $observaciones, 255);
    }

    execute_or_fail($statement, 'No fue posible registrar el pago.');
    oci_commit($connection);
    oci_free_statement($statement);

    send_json([
        'message' => $existente ? 'Pago actualizado correctamente.' : 'Pago registrado correctamente.',
        'pagos' => pagos_jugador($connection, $idJugador),
    ], $existente ? 200 : 201);
}

function pagos_jugador($connection, int $idJugador): array
{
    $sql = "SELECT ID_FACTURACION_INSCRIPCION,
                   MES,
                   ANIO,
                   MONTO,
                   TO_CHAR(FECHA_PAGO, 'YYYY-MM-DD') AS FECHA_PAGO,
                   OBSERVACIONES
            FROM FIDE_FACTURACION_INSCRIPCIONES_V
            WHERE ID_JUGADOR = :id_jugador
            ORDER BY ANIO DESC, MES DESC";

    $statement = oci_parse($connection, $sql);
    oci_bind_by_name($statement, ':id_jugador', $idJugador);
    execute_or_fail($statement, 'No fue posible listar pagos.');

    $pagos = [];
    while (($row = oci_fetch_assoc($statement)) !== false) {
        $pagos[] = $row;
    }

    oci_free_statement($statement);
    return $pagos;
}

function jugador_existe($connection, int $idJugador): bool
{
    $sql = "SELECT 1 AS EXISTE FROM FIDE_JUGADORES_V WHERE ID_JUGADOR = :id_jugador";
    $statement = oci_parse($connection, $sql);
    oci_bind_by_name($statement, ':id_jugador', $idJugador);
    execute_or_fail($statement, 'No fue posible validar el jugador.');
    $exists = (bool) oci_fetch_assoc($statement);
    oci_free_statement($statement);
    return $exists;
}

function pago_existente($connection, int $idJugador, int $mes, int $anio): ?int
{
    $sql = "SELECT ID_FACTURACION_INSCRIPCION
            FROM FIDE_FACTURACION_INSCRIPCIONES_V
            WHERE ID_JUGADOR = :id_jugador
              AND MES = :mes
              AND ANIO = :anio";
    $statement = oci_parse($connection, $sql);
    oci_bind_by_name($statement, ':id_jugador', $idJugador);
    oci_bind_by_name($statement, ':mes', $mes);
    oci_bind_by_name($statement, ':anio', $anio);
    execute_or_fail($statement, 'No fue posible validar pagos previos.');
    $row = oci_fetch_assoc($statement);
    oci_free_statement($statement);
    return $row ? (int) $row['ID_FACTURACION_INSCRIPCION'] : null;
}

function siguiente_id_factura($connection): int
{
    $statement = oci_parse($connection, 'SELECT NVL(MAX(ID_FACTURACION_INSCRIPCION), 0) + 1 AS ID FROM FIDE_FACTURACION_INSCRIPCIONES_V');
    execute_or_fail($statement, 'No fue posible generar el consecutivo de pago.');
    $row = oci_fetch_assoc($statement);
    oci_free_statement($statement);
    return (int) $row['ID'];
}

function execute_or_fail($statement, string $message): void
{
    if (!oci_execute($statement, OCI_NO_AUTO_COMMIT)) {
        $error = oci_error($statement);
        throw new RuntimeException($error['message'] ?? $message);
    }
}

function read_json_body(): array
{
    $rawBody = file_get_contents('php://input');
    $data = json_decode($rawBody ?: '{}', true);

    if (!is_array($data)) {
        send_json(['error' => 'JSON invalido.'], 400);
    }

    return $data;
}

function nullable_int($value): ?int
{
    return ($value === null || $value === '') ? null : (int) $value;
}

function nullable_float($value): ?float
{
    return ($value === null || $value === '') ? null : (float) $value;
}

function send_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
