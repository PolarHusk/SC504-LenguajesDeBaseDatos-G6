<?php

declare(strict_types=1);

require __DIR__ . '/db.php';
require __DIR__ . '/session.php';

start_app_session();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

$views = [
    'estados' => ['view' => 'FIDE_ESTADOS_V', 'label' => 'Estados'],
    'tipotarjetas' => ['view' => 'FIDE_TIPOTARJETAS_V', 'label' => 'Tipo de Tarjetas'],
    'cantones' => ['view' => 'FIDE_CANTONES_V', 'label' => 'Cantones'],
    'cargos' => ['view' => 'FIDE_CARGOS_V', 'label' => 'Cargos'],
    'categorias' => ['view' => 'FIDE_CATEGORIAS_V', 'label' => 'Categorias'],
    'categoria_inventario' => ['view' => 'FIDE_CATEGORIA_INVENTARIO_V', 'label' => 'Categoria Inventario'],
    'distritos' => ['view' => 'FIDE_DISTRITOS_V', 'label' => 'Distritos'],
    'especialidades' => ['view' => 'FIDE_ESPECIALIDADES_V', 'label' => 'Especialidades'],
    'posiciones' => ['view' => 'FIDE_POSICIONES_V', 'label' => 'Posiciones'],
    'provincias' => ['view' => 'FIDE_PROVINCIAS_V', 'label' => 'Provincias'],
    'temporadas' => ['view' => 'FIDE_TEMPORADAS_V', 'label' => 'Temporadas'],
    'tipolesion' => ['view' => 'FIDE_TIPOLESION_V', 'label' => 'Tipo Lesion'],
    'tipo_partidos' => ['view' => 'FIDE_TIPO_PARTIDOS_V', 'label' => 'Tipo Partidos'],
    'articulos' => ['view' => 'FIDE_ARTICULOS_V', 'label' => 'Articulos'],
    'direccion_exacta' => ['view' => 'FIDE_DIRECCION_EXACTA_V', 'label' => 'Direccion Exacta'],
    'medicos' => ['view' => 'FIDE_MEDICOS_V', 'label' => 'Medicos'],
    'empleados' => ['view' => 'FIDE_EMPLEADOS_V', 'label' => 'Empleados'],
    'jugadores' => ['view' => 'FIDE_JUGADORES_V', 'label' => 'Jugadores'],
    'facturacion_inscripciones' => ['view' => 'FIDE_FACTURACION_INSCRIPCIONES_V', 'label' => 'Facturacion Inscripciones'],
    'sedes' => ['view' => 'FIDE_SEDES_V', 'label' => 'Sedes'],
    'jugador_posiciones' => ['view' => 'FIDE_JUGADOR_POSICIONES_V', 'label' => 'Jugador Posiciones'],
    'parte_medico' => ['view' => 'FIDE_PARTE_MEDICO_V', 'label' => 'Parte Medico'],
    'partidos' => ['view' => 'FIDE_PARTIDOS_V', 'label' => 'Partidos'],
    'revision_fisica' => ['view' => 'FIDE_REVISION_FISICA_V', 'label' => 'Revision Fisica'],
    'telefonos' => ['view' => 'FIDE_TELEFONOS_V', 'label' => 'Telefonos'],
    'asistencia' => ['view' => 'FIDE_ASISTENCIA_V', 'label' => 'Asistencia'],
    'estadistica_equipo' => ['view' => 'FIDE_ESTADISTICA_EQUIPO_V', 'label' => 'Estadistica Equipo'],
    'estadistica_jugador' => ['view' => 'FIDE_ESTADISTICA_JUGADOR_V', 'label' => 'Estadistica Jugador'],
    'lesiones' => ['view' => 'FIDE_LESIONES_V', 'label' => 'Lesiones'],
    'tarjetas' => ['view' => 'FIDE_TARJETAS_V', 'label' => 'Tarjetas'],
    'detalle_jugadores' => ['view' => 'FIDE_DETALLE_JUGADORES_V', 'label' => 'Detalle Jugadores'],
    'detalle_partidos' => ['view' => 'FIDE_DETALLE_PARTIDOS_V', 'label' => 'Detalle Partidos'],
    'detalle_estadisticas_jugador' => ['view' => 'FIDE_DETALLE_ESTADISTICAS_JUGADOR_V', 'label' => 'Detalle Estadisticas Jugador'],
    'facturacion_jugadores' => ['view' => 'FIDE_FACTURACION_JUGADORES_V', 'label' => 'Facturacion Jugadores'],
    'lesiones_jugadores' => ['view' => 'FIDE_LESIONES_JUGADORES_V', 'label' => 'Lesiones Jugadores'],
    'calendario_partidos' => ['view' => 'FIDE_CALENDARIO_PARTIDOS_V', 'label' => 'Calendario Partidos'],
];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    if (!isset($_SESSION['empleado'])) {
        send_json(['error' => 'Debe iniciar sesion para listar vistas.'], 401);
    }

    $key = $_GET['vista'] ?? '';
    if (!isset($views[$key])) {
        send_json(['error' => 'Vista no permitida.'], 400);
    }

    list_view($views[$key]);
} catch (Throwable $exception) {
    send_json(['error' => $exception->getMessage()], 500);
}

function list_view(array $config): void
{
    $connection = db_connection();
    $sql = "SELECT * FROM {$config['view']}";
    $statement = oci_parse($connection, $sql);

    if (!oci_execute($statement)) {
        $error = oci_error($statement);
        throw new RuntimeException($error['message'] ?? 'No fue posible listar la vista.');
    }

    $records = [];
    while (($row = oci_fetch_assoc($statement)) !== false) {
        $records[] = $row;
    }

    oci_free_statement($statement);

    send_json([
        'message' => 'Vista cargada correctamente.',
        'view' => $config['label'],
        'records' => $records,
    ]);
}

function send_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
