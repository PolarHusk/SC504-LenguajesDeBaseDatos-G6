﻿const AUTH_URL = 'api/auth.php';
const CATALOG_URL = 'api/catalogos.php';
const PAYMENTS_URL = 'api/pagos.php';
const VIEWS_URL = 'api/vistas.php';

const catalogs = {
    estados: catalogDef('Estados', [numField('id', 'ID_ESTADO', 'ID Estado')], [textField('nombre', 'NOMBRE_ESTADO', 'Nombre del estado')], false),
    provincias: simpleCatalogDef('Provincias', 'ID_PROVINCIA', 'ID Provincia', 'NOMBRE_PROVINCIA', 'Nombre de provincia'),
    cantones: simpleCatalogDef('Cantones', 'ID_CANTON', 'ID Canton', 'NOMBRE_CANTON', 'Nombre de canton'),
    distritos: simpleCatalogDef('Distritos', 'ID_DISTRITO', 'ID Distrito', 'NOMBRE_DISTRITO', 'Nombre de distrito'),
    categorias: simpleCatalogDef('Categorias Deportivas', 'ID_CATEGORIA', 'ID Categoria', 'NOMBRE_CATEGORIA', 'Nombre de categoria'),
    posiciones: simpleCatalogDef('Posiciones', 'ID_POSICION', 'ID Posicion', 'NOMBRE_POSICION', 'Nombre de posicion'),
    cargos: simpleCatalogDef('Cargos', 'ID_CARGO', 'ID Cargo', 'NOMBRE_CARGO', 'Nombre de cargo'),
    especialidades: simpleCatalogDef('Especialidades', 'ID_ESPECIALIDAD', 'ID Especialidad', 'NOMBRE_ESPECIALIDAD', 'Nombre de especialidad'),
    tipotarjetas: simpleCatalogDef('Tipo de Tarjetas', 'ID_TIPOTARJETA', 'ID Tipo Tarjeta', 'COLOR', 'Color'),
    categoria_inventario: simpleCatalogDef('Categorias de Inventario', 'ID_CATEGORIAINVENTARIO', 'ID Categoria Inventario', 'NOMBRE_CATEGORIA_INVENTARIO', 'Nombre de categoria inventario'),
    tipolesion: simpleCatalogDef('Tipo Lesion', 'ID_TIPOLESION', 'ID Tipo Lesion', 'NOMBRE_TIPO_LESION', 'Nombre tipo lesion'),
    tipo_partidos: simpleCatalogDef('Tipo Partidos', 'ID_TIPOPARTIDOS', 'ID Tipo Partido', 'TIPO_DE_PARTIDO', 'Tipo de partido'),
    temporadas: catalogDef('Temporadas', [numField('id', 'ID_TEMPORADA', 'ID Temporada')], [textField('tipo_temporada', 'TIPO_TEMPORADA', 'Tipo temporada'), numField('anio', 'ANIO', 'Anio')]),
    articulos: catalogDef('Articulos', [numField('id', 'ID_ARTICULO', 'ID Articulo')], [numField('id_categoriainventario', 'ID_CATEGORIAINVENTARIO', 'ID Categoria inventario'), numField('cantidad', 'CANTIDAD', 'Cantidad'), textField('nombre_articulo', 'NOMBRE_ARTICULO', 'Nombre articulo')]),
    direccion_exacta: catalogDef('Direccion Exacta', [numField('id', 'ID_DIRECCION_EXACTA', 'ID Direccion')], [numField('id_distrito', 'ID_DISTRITO', 'ID Distrito'), numField('id_canton', 'ID_CANTON', 'ID Canton'), numField('id_provincia', 'ID_PROVINCIA', 'ID Provincia'), textField('otras_senias', 'OTRAS_SENIAS', 'Otras senias')]),
    medicos: catalogDef('Medicos', [numField('id', 'ID_MEDICO', 'ID Medico')], [textField('nombre', 'NOMBRE', 'Nombre'), textField('apellido_paterno', 'APELLIDO_PATERNO', 'Apellido paterno'), textField('apellido_materno', 'APELLIDO_MATERNO', 'Apellido materno'), numField('id_especialidad', 'ID_ESPECIALIDAD', 'ID Especialidad')]),
    empleados: catalogDef('Empleados', [numField('id', 'ID_EMPLEADO', 'ID Empleado')], [textField('nombre', 'NOMBRE', 'Nombre'), textField('apellido_paterno', 'APELLIDO_PATERNO', 'Apellido paterno'), textField('apellido_materno', 'APELLIDO_MATERNO', 'Apellido materno'), numField('edad', 'EDAD', 'Edad'), textField('nombre_de_usuario', 'NOMBRE_DE_USUARIO', 'Usuario'), textField('contrasenia', 'CONTRASENIA', 'Contrasenia'), numField('id_cargo', 'ID_CARGO', 'ID Cargo'), numField('id_direccion_exacta', 'ID_DIRECCION_EXACTA', 'ID Direccion')]),
    jugadores: catalogDef('Jugadores', [numField('id', 'ID_JUGADOR', 'ID Jugador')], [numField('id_categoria', 'ID_CATEGORIA', 'ID Categoria'), textField('nombre', 'NOMBRE', 'Nombre'), textField('apellido_materno', 'APELLIDO_MATERNO', 'Apellido materno'), textField('apellido_paterno', 'APELLIDO_PATERNO', 'Apellido paterno'), numField('dorsal', 'DORSAL', 'Dorsal'), numField('edad', 'EDAD', 'Edad'), numField('id_direccion_exacta', 'ID_DIRECCION_EXACTA', 'ID Direccion')]),
    sedes: catalogDef('Sedes', [numField('id', 'ID_SEDE', 'ID Sede')], [textField('nombre_sede', 'NOMBRE_SEDE', 'Nombre sede'), numField('id_direccion_exacta', 'ID_DIRECCION_EXACTA', 'ID Direccion')]),
    jugador_posiciones: catalogDef('Jugador Posiciones', [numField('id_jugador', 'ID_JUGADOR', 'ID Jugador'), numField('id_posicion_actual', 'ID_POSICION', 'ID Posicion')], [numField('id_posicion_nueva', 'ID_POSICION', 'ID Posicion nueva', { editOnly: true, table: false })], false),
    parte_medico: catalogDef('Parte Medico', [numField('id', 'ID_PARTEMEDICO', 'ID Parte medico')], [numField('id_jugador', 'ID_JUGADOR', 'ID Jugador'), dateField('fecha', 'FECHA', 'Fecha'), numField('id_medico', 'ID_MEDICO', 'ID Medico'), textField('observaciones', 'OBSERVACIONES', 'Observaciones')]),
    partidos: catalogDef('Partidos', [numField('id', 'ID_PARTIDO', 'ID Partido')], [numField('id_categoria', 'ID_CATEGORIA', 'ID Categoria'), numField('id_tipopartidos', 'ID_TIPOPARTIDOS', 'ID Tipo partido'), numField('id_temporada', 'ID_TEMPORADA', 'ID Temporada'), dateField('fecha', 'FECHA', 'Fecha'), textField('rival', 'RIVAL', 'Rival'), numField('goles_favor', 'GOLES_FAVOR', 'Goles favor'), numField('goles_contra', 'GOLES_CONTRA', 'Goles contra'), numField('id_sede', 'ID_SEDE', 'ID Sede')]),
    revision_fisica: catalogDef('Revision Fisica', [numField('id', 'ID_REVISION', 'ID Revision')], [numField('id_jugador', 'ID_JUGADOR', 'ID Jugador'), numField('peso', 'PESO', 'Peso'), numField('imc', 'IMC', 'IMC'), numField('altura', 'ALTURA', 'Altura'), dateField('fecha_revision', 'FECHA_REVISION', 'Fecha revision')]),
    telefonos: catalogDef('Telefonos', [numField('id', 'ID_TELEFONO', 'ID Telefono')], [textField('numero_telefono', 'NUMERO_TELEFONO', 'Numero telefono'), numField('id_empleado', 'ID_EMPLEADO', 'ID Empleado')]),
    asistencia: catalogDef('Asistencia', [numField('id_partido', 'ID_PARTIDO', 'ID Partido'), numField('id_jugador', 'ID_JUGADOR', 'ID Jugador')], []),
    estadistica_equipo: catalogDef('Estadistica Equipo', [numField('id', 'ID_ESTADISTICA_EQUIPO', 'ID Estadistica equipo')], [numField('tiros', 'TIROS', 'Tiros'), numField('tiros_porteria', 'TIROS_PORTERIA', 'Tiros porteria'), numField('pases_exitosos', 'PASES_EXITOSOS', 'Pases exitosos'), numField('pases_fallidos', 'PASES_FALLIDOS', 'Pases fallidos'), numField('posesion_balon', 'POSESION_BALON', 'Posesion balon'), numField('id_partido', 'ID_PARTIDO', 'ID Partido')]),
    estadistica_jugador: catalogDef('Estadistica Jugador', [numField('id', 'ID_ESTADISTICA_JUGADOR', 'ID Estadistica jugador')], [numField('id_jugador', 'ID_JUGADOR', 'ID Jugador'), numField('id_partido', 'ID_PARTIDO', 'ID Partido'), numField('pases', 'PASES', 'Pases'), numField('pases_exitosos', 'PASES_EXITOSOS', 'Pases exitosos'), numField('regates', 'REGATES', 'Regates'), numField('regates_exitosos', 'REGATES_EXITOSOS', 'Regates exitosos'), numField('tiros', 'TIROS', 'Tiros'), numField('tiros_exitosos', 'TIROS_EXITOSOS', 'Tiros exitosos'), numField('entradas', 'ENTRADAS', 'Entradas'), numField('entradas_exitosas', 'ENTRADAS_EXITOSAS', 'Entradas exitosas'), numField('minutos_jugados', 'MINUTOS_JUGADOS', 'Minutos jugados'), numField('goles', 'GOLES', 'Goles'), numField('asistencias', 'ASISTENCIAS', 'Asistencias')]),
    lesiones: catalogDef('Lesiones', [numField('id', 'ID_LESION', 'ID Lesion')], [dateField('fecha_recuperacion', 'FECHA_RECUPERACION', 'Fecha recuperacion'), numField('id_tipolesion', 'ID_TIPOLESION', 'ID Tipo lesion'), numField('id_partemedico', 'ID_PARTEMEDICO', 'ID Parte medico'), textField('descripcion', 'DESCRIPCION', 'Descripcion')]),
    tarjetas: catalogDef('Tarjetas', [numField('id_partido', 'ID_PARTIDO', 'ID Partido'), numField('id_jugador', 'ID_JUGADOR', 'ID Jugador'), numField('id_tipotarjeta', 'ID_TIPOTARJETA', 'ID Tipo tarjeta')], [numField('cantidad_tarjetas', 'CANTIDAD_TARJETAS', 'Cantidad tarjetas')]),
    facturacion_inscripciones: catalogDef('Facturacion Inscripciones', [numField('id', 'ID_FACTURACION_INSCRIPCION', 'ID Factura')], [numField('id_jugador', 'ID_JUGADOR', 'ID Jugador'), numField('mes', 'MES', 'Mes'), numField('anio', 'ANIO', 'Anio'), numField('monto', 'MONTO', 'Monto'), dateField('fecha_pago', 'FECHA_PAGO', 'Fecha pago'), textField('observaciones', 'OBSERVACIONES', 'Observaciones')]),
};

const views = {
    estados: 'Estados',
    tipotarjetas: 'Tipo de Tarjetas',
    cantones: 'Cantones',
    cargos: 'Cargos',
    categorias: 'Categorias',
    categoria_inventario: 'Categoria Inventario',
    distritos: 'Distritos',
    especialidades: 'Especialidades',
    posiciones: 'Posiciones',
    provincias: 'Provincias',
    temporadas: 'Temporadas',
    tipolesion: 'Tipo Lesion',
    tipo_partidos: 'Tipo Partidos',
    articulos: 'Articulos',
    direccion_exacta: 'Direccion Exacta',
    medicos: 'Medicos',
    empleados: 'Empleados',
    jugadores: 'Jugadores',
    facturacion_inscripciones: 'Facturacion Inscripciones',
    sedes: 'Sedes',
    jugador_posiciones: 'Jugador Posiciones',
    parte_medico: 'Parte Medico',
    partidos: 'Partidos',
    revision_fisica: 'Revision Fisica',
    telefonos: 'Telefonos',
    asistencia: 'Asistencia',
    estadistica_equipo: 'Estadistica Equipo',
    estadistica_jugador: 'Estadistica Jugador',
    lesiones: 'Lesiones',
    tarjetas: 'Tarjetas',
    detalle_jugadores: 'Detalle Jugadores',
    detalle_partidos: 'Detalle Partidos',
    detalle_estadisticas_jugador: 'Detalle Estadisticas Jugador',
    facturacion_jugadores: 'Facturacion Jugadores',
    lesiones_jugadores: 'Lesiones Jugadores',
    calendario_partidos: 'Calendario Partidos',
};

function catalogDef(title, pkFields, fields, hasEstado = true) {
    return { title, pkFields, fields, hasEstado };
}

function simpleCatalogDef(title, idColumn, idLabel, nameColumn, nameLabel) {
    return catalogDef(title, [numField('id', idColumn, idLabel)], [textField('nombre', nameColumn, nameLabel)]);
}

function numField(key, column, label, options = {}) {
    return { key, column, label, type: 'number', ...options };
}

function textField(key, column, label, options = {}) {
    return { key, column, label, type: 'text', ...options };
}

function dateField(key, column, label, options = {}) {
    return { key, column, label, type: 'date', ...options };
}

let currentCatalog = 'estados';
let currentView = '';
let currentMode = 'catalog';
let records = [];
let selectedRecord = null;
const catalogCache = new Map();
const viewCache = new Map();

const accessView = document.getElementById('accessView');
const adminView = document.getElementById('adminView');
const loginForm = document.getElementById('loginForm');
const loginMessage = document.getElementById('loginMessage');
const logoutBtn = document.getElementById('logoutBtn');
const sessionUser = document.getElementById('sessionUser');
const searchPlayerForm = document.getElementById('searchPlayerForm');
const paymentMessage = document.getElementById('paymentMessage');
const playerPaymentBox = document.getElementById('playerPaymentBox');
const paymentForm = document.getElementById('paymentForm');
const paymentMonth = document.getElementById('paymentMonth');
const paymentYear = document.getElementById('paymentYear');
const paymentAmount = document.getElementById('paymentAmount');
const paymentNotes = document.getElementById('paymentNotes');
const paymentPlayerId = document.getElementById('paymentPlayerId');
const playerName = document.getElementById('playerName');
const playerMeta = document.getElementById('playerMeta');
const paymentsTable = document.getElementById('paymentsTable');
const catalogMenu = document.getElementById('catalogMenu');
const viewMenu = document.getElementById('viewMenu');
const catalogTitle = document.getElementById('catalogTitle');
const contentGrid = document.getElementById('contentGrid');
const catalogForm = document.getElementById('catalogForm');
const formTitle = document.getElementById('formTitle');
const modeInput = document.getElementById('mode');
const recordIdLabel = document.querySelector('label[for="recordId"]');
const recordIdInput = document.getElementById('recordId');
const extraKeyFields = document.getElementById('extraKeyFields');
const recordNameField = document.getElementById('recordNameField');
const recordNameInput = document.getElementById('recordName');
const extraDataFields = document.getElementById('extraDataFields');
const recordStatusField = document.getElementById('recordStatusField');
const recordStatusSelect = document.getElementById('recordStatus');
const statusLabel = document.getElementById('statusLabel');
const recordNameLabel = document.getElementById('recordNameLabel');
const nameColumnHeader = document.getElementById('nameColumnHeader');
const recordsHead = document.getElementById('recordsHead');
const recordsTable = document.getElementById('recordsTable');
const clearBtn = document.getElementById('clearBtn');
const deleteBtn = document.getElementById('deleteBtn');
const reloadBtn = document.getElementById('reloadBtn');
const messageBox = document.getElementById('messageBox');
const searchInput = document.getElementById('searchInput');
const totalRecords = document.getElementById('totalRecords');
const activeRecords = document.getElementById('activeRecords');
const inactiveRecords = document.getElementById('inactiveRecords');

function init() {
    buildMonthOptions();
    bindTabs();
    loginForm.addEventListener('submit', login);
    logoutBtn.addEventListener('click', logout);
    searchPlayerForm.addEventListener('submit', searchPlayer);
    paymentForm.addEventListener('submit', registerPayment);
    catalogForm.addEventListener('submit', saveCatalog);
    recordsTable.addEventListener('click', handleTableClick);
    deleteBtn.addEventListener('click', deleteRecord);
    clearBtn.addEventListener('click', clearForm);
    reloadBtn.addEventListener('click', () => currentMode === 'view' ? loadViewRecords(true) : loadRecords(true));
    searchInput.addEventListener('input', () => currentMode === 'view' ? renderViewRecords() : renderRecords());
    checkSession();
}

function bindTabs() {
    document.querySelectorAll('[data-bs-toggle="pill"]').forEach((tab) => {
        tab.addEventListener('click', () => {
            const target = document.querySelector(tab.dataset.bsTarget);
            if (!target) return;

            document.querySelectorAll('[data-bs-toggle="pill"]').forEach((item) => item.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach((pane) => pane.classList.remove('show', 'active'));

            tab.classList.add('active');
            target.classList.add('show', 'active');
        });
    });
}

async function checkSession() {
    try {
        const data = await requestJson(`${AUTH_URL}?action=status`);
        if (data.authenticated) showAdmin(data.user);
    } catch (error) {
        showAccess();
    }
}

async function login(event) {
    event.preventDefault();
    const payload = {
        usuario: document.getElementById('loginUser').value.trim(),
        contrasenia: document.getElementById('loginPassword').value.trim(),
    };

    try {
        const data = await requestJson(`${AUTH_URL}?action=login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        loginForm.reset();
        showMessage(loginMessage, data.message);
        showAdmin(data.user);
    } catch (error) {
        showMessage(loginMessage, error.message, true);
    }
}

async function logout() {
    await fetch(`${AUTH_URL}?action=logout`, { method: 'POST' });
    showAccess();
}

function showAdmin(user) {
    accessView.classList.add('hidden');
    adminView.classList.remove('hidden');
    sessionUser.textContent = user?.nombre || user?.usuario || 'Panel administrativo';
    buildMenu();
    buildViewMenu();
    applyCatalogLabels();
    loadRecords();
}

function showAccess() {
    adminView.classList.add('hidden');
    accessView.classList.remove('hidden');
}

function buildMonthOptions() {
    const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    paymentMonth.innerHTML = months.map((month, index) => `<option value="${index + 1}">${month}</option>`).join('');
    const now = new Date();
    paymentMonth.value = String(now.getMonth() + 1);
    paymentYear.value = String(now.getFullYear());
}

async function searchPlayer(event) {
    event.preventDefault();
    const cedula = document.getElementById('cedulaInput').value.trim();

    try {
        const data = await requestJson(`${PAYMENTS_URL}?cedula=${encodeURIComponent(cedula)}`);
        renderPlayer(data.jugador, data.pagos || []);
        showMessage(paymentMessage, data.message);
    } catch (error) {
        playerPaymentBox.classList.add('hidden');
        showMessage(paymentMessage, error.message, true);
    }
}

function renderPlayer(player, payments) {
    paymentPlayerId.value = player.ID_JUGADOR;
    paymentAmount.value = '';
    paymentNotes.value = '';
    playerName.textContent = `${player.NOMBRE || ''} ${player.APELLIDO_PATERNO || ''} ${player.APELLIDO_MATERNO || ''}`.trim();
    playerMeta.textContent = `Cedula ${player.ID_JUGADOR} | Categoria ${player.NOMBRE_CATEGORIA || 'Sin categoria'} | Dorsal ${player.DORSAL || '-'}`;
    renderPayments(payments);
    playerPaymentBox.classList.remove('hidden');
}

async function registerPayment(event) {
    event.preventDefault();
    const payload = {
        id_jugador: Number(paymentPlayerId.value),
        mes: Number(paymentMonth.value),
        anio: Number(paymentYear.value),
        monto: Number(paymentAmount.value),
        observaciones: paymentNotes.value.trim(),
    };

    try {
        const data = await requestJson(PAYMENTS_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        showMessage(paymentMessage, data.message);
        renderPayments(data.pagos || []);
        paymentForm.reset();
        buildMonthOptions();
    } catch (error) {
        showMessage(paymentMessage, error.message, true);
    }
}

function renderPayments(payments) {
    paymentsTable.innerHTML = payments.length
        ? payments.map((payment) => `
            <tr>
                <td>${escapeHtml(payment.ID_FACTURACION_INSCRIPCION)}</td>
                <td>${escapeHtml(payment.MES)}/${escapeHtml(payment.ANIO)}</td>
                <td>${formatMoney(payment.MONTO)}</td>
                <td>${escapeHtml(payment.FECHA_PAGO || '-')}</td>
            </tr>
        `).join('')
        : '<tr><td colspan="4">Este jugador no registra pagos.</td></tr>';
}

function buildMenu() {
    catalogMenu.innerHTML = '';
    Object.entries(catalogs).forEach(([key, catalog]) => {
        const button = document.createElement('button');
        button.textContent = catalog.title;
        button.className = currentMode === 'catalog' && key === currentCatalog ? 'active' : '';
        button.addEventListener('click', () => changeCatalog(key));
        catalogMenu.appendChild(button);
    });
}

function buildViewMenu() {
    viewMenu.innerHTML = '';
    Object.entries(views).forEach(([key, title]) => {
        const button = document.createElement('button');
        button.textContent = title;
        button.className = currentMode === 'view' && key === currentView ? 'active' : '';
        button.addEventListener('click', () => changeView(key));
        viewMenu.appendChild(button);
    });
}

function changeCatalog(key) {
    currentMode = 'catalog';
    currentCatalog = key;
    currentView = '';
    clearForm();
    buildMenu();
    buildViewMenu();
    applyCatalogLabels();
    contentGrid.classList.remove('view-mode');
    catalogForm.classList.remove('hidden');
    loadRecords();
}

function changeView(key) {
    currentMode = 'view';
    currentView = key;
    clearForm();
    buildMenu();
    buildViewMenu();
    catalogTitle.textContent = views[key];
    contentGrid.classList.add('view-mode');
    contentGrid.classList.remove('expanded-form');
    catalogForm.classList.add('hidden');
    loadViewRecords();
}

function applyCatalogLabels() {
    const catalog = catalogs[currentCatalog];
    const firstPk = catalog.pkFields[0];
    const firstField = catalog.fields[0];
    const isExpanded = isComplexCatalog(catalog);

    catalogTitle.textContent = catalog.title;
    contentGrid.classList.toggle('expanded-form', isExpanded);
    catalogForm.classList.toggle('expanded', isExpanded);
    recordIdLabel.textContent = firstPk.label;
    recordIdInput.type = firstPk.type;
    recordIdInput.step = firstPk.type === 'number' ? 'any' : '';
    recordIdInput.placeholder = firstPk.label;
    renderDynamicInputs(extraKeyFields, catalog.pkFields.slice(1));

    if (firstField) {
        recordNameField.classList.remove('hidden');
        recordNameInput.required = true;
        recordNameLabel.textContent = firstField.label;
        recordNameInput.type = firstField.type;
        recordNameInput.step = firstField.type === 'number' ? 'any' : '';
        recordNameInput.placeholder = firstField.label;
        recordNameInput.dataset.fieldKey = firstField.key;
    } else {
        recordNameField.classList.add('hidden');
        recordNameInput.required = false;
        recordNameInput.dataset.fieldKey = '';
    }

    renderDynamicInputs(extraDataFields, catalog.fields.slice(1));
    recordStatusField.classList.toggle('hidden', !catalog.hasEstado);
    setEditOnlyFields(false);
}

function renderDynamicInputs(container, fields) {
    container.innerHTML = fields.map((field) => `
        <div class="field-control ${isWideField(field) ? 'wide-field' : ''} ${field.editOnly ? 'edit-only-field hidden' : ''}">
            <label for="field_${field.key}">${escapeHtml(field.label)}</label>
            ${renderFieldControl(field)}
        </div>
    `).join('');
}

function renderFieldControl(field) {
    if (isWideField(field)) {
        return `
            <textarea
                id="field_${field.key}"
                class="form-control dynamic-field uniform-input"
                data-field-key="${escapeHtml(field.key)}"
                placeholder="${escapeHtml(field.label)}"
                rows="3"
                required></textarea>
        `;
    }

    const step = field.type === 'number' ? ' step="any"' : '';
    const required = field.editOnly ? '' : ' required';
    return `
        <input
            type="${escapeHtml(field.type)}"
            id="field_${field.key}"
            class="form-control dynamic-field uniform-input"
            data-field-key="${escapeHtml(field.key)}"
            placeholder="${escapeHtml(field.label)}"
            ${step}
            ${required}>
    `;
}

function isComplexCatalog(catalog) {
    return catalog.pkFields.length > 1 || catalog.fields.length > 2;
}

function isWideField(field) {
    return ['observaciones', 'descripcion', 'otras_senias'].includes(field.key);
}

async function loadRecords(forceRefresh = false) {
    if (!forceRefresh && catalogCache.has(currentCatalog)) {
        records = catalogCache.get(currentCatalog);
        renderRecords();
        showMessage(messageBox, 'Registros cargados desde memoria.');
        return;
    }

    try {
        const data = await requestJson(`${CATALOG_URL}?catalogo=${encodeURIComponent(currentCatalog)}`);
        records = data.records || [];
        catalogCache.set(currentCatalog, records);
        renderRecords();
        showMessage(messageBox, data.message || 'Registros cargados correctamente.');
    } catch (error) {
        if (error.status === 401) showAccess();
        showMessage(messageBox, error.message, true);
    }
}

async function loadViewRecords(forceRefresh = false) {
    if (!forceRefresh && viewCache.has(currentView)) {
        records = viewCache.get(currentView);
        renderViewRecords();
        showMessage(messageBox, 'Vista cargada desde memoria.');
        return;
    }

    try {
        const data = await requestJson(`${VIEWS_URL}?vista=${encodeURIComponent(currentView)}`);
        records = data.records || [];
        viewCache.set(currentView, records);
        renderViewRecords();
        showMessage(messageBox, data.message || 'Vista cargada correctamente.');
    } catch (error) {
        if (error.status === 401) showAccess();
        showMessage(messageBox, error.message, true);
    }
}

function normalizeRecords(items) {
    const catalog = catalogs[currentCatalog];
    return items.map((record) => ({
        ...record,
        ID: record.ID ?? record[findKey(record, 'ID_')],
        NOMBRE: record.NOMBRE ?? record[findNameKey(record)] ?? '',
        ID_ESTADO: record.ID_ESTADO ?? (catalog.hasEstado ? null : 1),
        NOMBRE_ESTADO: record.NOMBRE_ESTADO ?? '',
    }));
}

function findKey(record, prefix) {
    return Object.keys(record).find((key) => key.startsWith(prefix));
}

function findNameKey(record) {
    return Object.keys(record).find((key) => key.includes('NOMBRE') || key === 'COLOR' || key.includes('TIPO'));
}

function renderRecords() {
    const catalog = catalogs[currentCatalog];
    const columns = getCatalogColumns(catalog);
    const hasEstado = catalog.hasEstado;
    recordsHead.innerHTML = `
        <tr>
            ${columns.map((field) => `<th>${escapeHtml(field.label)}</th>`).join('')}
            ${hasEstado ? '<th>Estado</th>' : ''}
            <th>Acciones</th>
        </tr>
    `;
    const term = searchInput.value.trim().toLowerCase();
    const filtered = records.filter((record) => {
        return getCatalogColumns(catalog, true).some((field) => String(getRecordValue(record, field) ?? '').toLowerCase().includes(term));
    });
    recordsTable.innerHTML = '';

    if (filtered.length === 0) {
        recordsTable.innerHTML = `<tr><td colspan="${columns.length + (hasEstado ? 2 : 1)}">No hay registros para mostrar.</td></tr>`;
    }

    filtered.forEach((record) => {
        const row = document.createElement('tr');
        const recordIndex = records.indexOf(record);
        const estadoNombre = record.NOMBRE_ESTADO || 'Sin estado';
        const isInactive = String(record.ID_ESTADO) === '2' || String(estadoNombre).toLowerCase().includes('inactivo');

        row.innerHTML = `
            ${columns.map((field) => `<td>${escapeHtml(formatRecordValue(getRecordValue(record, field), field))}</td>`).join('')}
            ${hasEstado ? `<td><span class="badge-status ${isInactive ? 'inactive' : ''}">${escapeHtml(estadoNombre)}</span></td>` : ''}
            <td><div class="row-actions"><button class="small-btn" data-action="edit" data-index="${recordIndex}">Editar</button><button class="small-btn" data-action="delete" data-index="${recordIndex}">Desactivar</button></div></td>
        `;
        recordsTable.appendChild(row);
    });
    updateStats();
}

function getCatalogColumns(catalog, includeStatus = false) {
    const columns = [...catalog.pkFields, ...catalog.fields].filter((field) => field.table !== false);
    return includeStatus && catalog.hasEstado ? [...columns, numField('id_estado', 'ID_ESTADO', 'Estado')] : columns;
}

function getRecordValue(record, field) {
    if (!field) return '';
    const sourceColumn = field.sourceColumn || field.column;
    return record[sourceColumn] ?? record[field.column] ?? record[field.key] ?? '';
}

function formatRecordValue(value, field) {
    if (!value || field.type !== 'date') return value ?? '';
    return String(value).slice(0, 10);
}

function renderViewRecords() {
    const term = searchInput.value.trim().toLowerCase();
    const columns = records.length ? Object.keys(records[0]) : [];
    const filtered = records.filter((record) => {
        return Object.values(record).some((value) => String(value ?? '').toLowerCase().includes(term));
    });

    recordsHead.innerHTML = columns.length
        ? `<tr>${columns.map((column) => `<th>${escapeHtml(column)}</th>`).join('')}</tr>`
        : '<tr><th>Registros</th></tr>';

    recordsTable.innerHTML = '';

    if (filtered.length === 0) {
        recordsTable.innerHTML = `<tr><td colspan="${Math.max(columns.length, 1)}">No hay registros para mostrar.</td></tr>`;
    }

    filtered.forEach((record) => {
        const row = document.createElement('tr');
        row.innerHTML = columns.map((column) => `<td>${escapeHtml(record[column])}</td>`).join('');
        recordsTable.appendChild(row);
    });

    totalRecords.textContent = records.length;
    activeRecords.textContent = '-';
    inactiveRecords.textContent = '-';
}

function updateStats() {
    const active = records.filter((record) => String(record.ID_ESTADO || '1') === '1').length;
    totalRecords.textContent = records.length;
    activeRecords.textContent = currentCatalog === 'estados' ? '-' : active;
    inactiveRecords.textContent = currentCatalog === 'estados' ? '-' : records.length - active;
}

async function saveCatalog(event) {
    event.preventDefault();
    const payload = readCatalogForm();
    const method = modeInput.value === 'edit' ? 'PUT' : 'POST';

    try {
        const data = await requestJson(`${CATALOG_URL}?catalogo=${encodeURIComponent(currentCatalog)}`, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        showMessage(messageBox, data.message || 'Guardado correctamente.');
        clearForm();
        catalogCache.delete(currentCatalog);
        loadRecords(true);
    } catch (error) {
        showMessage(messageBox, error.message, true);
    }
}

function handleTableClick(event) {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const record = records[Number(button.dataset.index)];
    if (!record) return;
    if (button.dataset.action === 'edit') fillForm(record);
    if (button.dataset.action === 'delete') {
        fillForm(record);
        deleteRecord();
    }
}

function fillForm(record) {
    const catalog = catalogs[currentCatalog];
    selectedRecord = record;
    modeInput.value = 'edit';
    formTitle.textContent = 'Modificar registro';
    recordIdInput.value = formatRecordValue(getRecordValue(record, catalog.pkFields[0]), catalog.pkFields[0]);
    recordIdInput.readOnly = true;

    setDynamicInputValues(catalog.pkFields.slice(1), record, true);

    if (catalog.fields[0]) {
        recordNameInput.value = formatRecordValue(getRecordValue(record, catalog.fields[0]), catalog.fields[0]);
    }

    setDynamicInputValues(catalog.fields.slice(1), record, false);
    setEditOnlyFields(true);
    recordStatusSelect.value = record.ID_ESTADO || '1';
    deleteBtn.disabled = false;
}

function clearForm() {
    const catalog = catalogs[currentCatalog];
    selectedRecord = null;
    modeInput.value = 'create';
    formTitle.textContent = 'Nuevo registro';
    recordIdInput.value = '';
    recordIdInput.readOnly = false;
    recordNameInput.value = '';
    [...extraKeyFields.querySelectorAll('.dynamic-field'), ...extraDataFields.querySelectorAll('.dynamic-field')].forEach((input) => {
        input.value = '';
        input.readOnly = false;
    });
    catalog.pkFields.slice(1).forEach((field) => {
        const input = getDynamicInput(field.key);
        if (input) input.readOnly = false;
    });
    setEditOnlyFields(false);
    recordStatusSelect.value = '1';
    deleteBtn.disabled = true;
}

async function deleteRecord() {
    const catalog = catalogs[currentCatalog];
    const payload = selectedRecord ? buildPayloadFromRecord(selectedRecord) : readCatalogForm();
    const message = currentCatalog === 'estados'
        ? 'Esto cambiara el nombre del estado a Inactivo. Desea continuar?'
        : catalog.hasEstado
            ? 'Esto cambiara el ID_ESTADO del registro a Inactivo. Desea continuar?'
            : 'Esto ejecutara el procedimiento de eliminacion del registro. Desea continuar?';
    if (!confirm(message)) return;

    try {
        const data = await requestJson(`${CATALOG_URL}?catalogo=${encodeURIComponent(currentCatalog)}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        showMessage(messageBox, data.message || 'Registro desactivado correctamente.');
        clearForm();
        catalogCache.delete(currentCatalog);
        loadRecords(true);
    } catch (error) {
        showMessage(messageBox, error.message, true);
    }
}

function readCatalogForm() {
    const catalog = catalogs[currentCatalog];
    const payload = {};
    const firstPk = catalog.pkFields[0];

    payload[firstPk.key] = readInputValue(recordIdInput, firstPk);

    catalog.pkFields.slice(1).forEach((field) => {
        const input = getDynamicInput(field.key);
        payload[field.key] = readInputValue(input, field);
    });

    if (catalog.fields[0]) {
        payload[catalog.fields[0].key] = readInputValue(recordNameInput, catalog.fields[0]);
    }

    catalog.fields.slice(1).forEach((field) => {
        const input = getDynamicInput(field.key);
        payload[field.key] = readInputValue(input, field);
    });

    if (catalog.hasEstado) {
        payload.id_estado = Number(recordStatusSelect.value);
    }

    return payload;
}

function buildPayloadFromRecord(record) {
    const catalog = catalogs[currentCatalog];
    const payload = {};

    getCatalogColumns(catalog, true).forEach((field) => {
        payload[field.key] = getRecordValue(record, field);
    });

    if (catalog.hasEstado) {
        payload.id_estado = Number(record.ID_ESTADO || 2);
    }

    return payload;
}

function setDynamicInputValues(fields, record, readOnly) {
    fields.forEach((field) => {
        const input = getDynamicInput(field.key);
        if (!input) return;
        input.value = formatRecordValue(getRecordValue(record, field), field);
        input.readOnly = readOnly;
    });
}

function setEditOnlyFields(isEdit) {
    document.querySelectorAll('.edit-only-field').forEach((fieldBox) => {
        fieldBox.classList.toggle('hidden', !isEdit);
        fieldBox.querySelectorAll('input, textarea, select').forEach((input) => {
            input.required = isEdit;
            input.disabled = !isEdit;
        });
    });
}

function getDynamicInput(key) {
    return document.querySelector(`[data-field-key="${key}"]`);
}

function readInputValue(input, field) {
    if (!input) return null;
    const value = input.value.trim();
    if (field.type === 'number') return value === '' ? null : Number(value);
    return value;
}

async function requestJson(url, options = {}) {
    const response = await fetch(url, options);
    const data = await response.json();
    if (!response.ok) {
        const error = new Error(data.error || 'No fue posible completar la solicitud.');
        error.status = response.status;
        throw error;
    }
    return data;
}

function showMessage(box, message, isError = false) {
    box.textContent = message;
    box.classList.remove('hidden', 'error');
    if (isError) box.classList.add('error');
}

function formatMoney(value) {
    return Number(value || 0).toLocaleString('es-CR', { style: 'currency', currency: 'CRC' });
}

function escapeHtml(value) {
    return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

init();

